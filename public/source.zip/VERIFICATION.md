# AstroFlare judging verification — 14 November 2026

## Current midnight/control-audit release

**Current result:** 34/34 automated tests passed. Anonymous production HTTP and DOM acceptance passed on application commit `eb4c14aaae8cefdc6a6971bd8cd6463070090e06`; homepage delivery was 872 ms in that run. Full machine-readable conditions/results: `/release-checks.json`. This timing is HTTP delivery, not a human or rendered-browser stopwatch.

| Current acceptance area | Status | Conditions |
| --- | --- | --- |
| Public homepage, docs and downloads | Pass | Anonymous HTTP 200; no account, cookies or bypass token; source ZIP exactly matches tested local archive and rebuilds the HTML/Worker. |
| Lunar demo, filters, comparison, research brief | Pass | Fresh production DOM sessions at configured widths 1280 and 390; all 21 filter cases, comparison limits/removal, Silicone/Opposed run gap, reset/empty recovery, copied payload and denied-clipboard fallback. |
| Questions, aliases, evidence gaps and rapid submissions | Pass | Published HTML; exact/alias Saffire II, separate Saffire I PSI/NTRS citations, silicone and lunar gaps, blank/unrelated queries, mouse/Enter/examples and latest-answer assertions. |
| Custom editor, disclosures, drafts and storage | Pass | Published DOM at 1280, 768 and 390; unsent drafts preserved, explicit remove controls, focus/state retention, save/load, corrupt and denied storage, reset confirmation. |
| NASA original sources | Pass | All three PSI records, metadata endpoints, original CSVs and pinned hashes; NTRS record/PDF returned 200. Units/run fields checked against pinned raw sources. |
| Mission validation, async cancellation, baseline/tools, reports | Pass with fixtures | Explicit service fixtures exercise real UI actions and export payloads; no substituted production results. All 34 local tests passed. |
| Fresh production mission/report | Blocked | Published `/api/guide/flow` returned 429; separate original assessment service must restore availability. No fresh report success claimed. |
| Motion and accessibility logic | Pass programmatically | Focus, native semantic controls, Enter submission, reduced-motion suppression, absent/throwing animation APIs and declared color contrast. |
| Rendered desktop/tablet/mobile and native-device checks | Blocked | No callable browser-control tool; actual layout/overflow, native clipboard/print, touch and OS reduced-motion appearance not verified. |
| Official challenge brief | Blocked | External URL returned HTTP 503; NASA source links passed independently. |
| GitHub creation/upload | Blocked | Integration rejects repository creation; owner must create the empty private repository and grant access. Existing Sites source is committed. |

The complete before-change control inventory is `/control-audit`. This release adds regression coverage for custom-question opening/validation/draft retention, comparison removal and disclosure state, mission draft persistence, corrupt/denied storage, cancellation of obsolete interpretation/flow/assessment/report/investigation responses, unknown/unit/basis controls, profile failure retry, Back network failure, every investigation action, source-verification recovery, pinned baseline comparison, and opening Report from the stepper. Motion-API absence/failure and reduced-motion preferences must leave content visible and controls functional.

Local source audit preserves all eight NASA PSI rows plus the separately cited Saffire I companion results. No measurement or relevance formula changes in this release. Both current report formats retain the corrected fault current integral (I²t) terminology and exact numeric values.

The current design uses flat charcoal/midnight surfaces, Instrument Serif/Sans, warm white text, selective electric blue controls and copper measurement accents. Tested declared foreground/background color pairs: body 15.81:1, secondary 8.70:1, NASA source 8.44:1, copper measurement 6.49:1, primary button 7.90:1, warning 8.54:1, error 7.97:1. This does not certify actual rendered-page contrast or visual layout.

Post-publish acceptance repeats core and scientific checks at DOM widths 1280/390 and new reliability checks at 1280/768/390, using anonymously downloaded production HTML. Original NASA links, pinned CSV hashes, source archive, documentation, dataset, fonts and control audit are checked separately over HTTP. A fresh screening/report attempt must be reported separately from fixture success.

GitHub creation is currently **Blocked** by `Resource not accessible by integration (createRepository)`. The owner must create an empty private `astroflare` repository and permit the connection to access it. A CI workflow is included and the project remains saved in its existing Sites Git repository.

**AI remains inactive pending the API key.** No generated requests or simulated AI responses. **Real browser visual/native checks remain Blocked** because no browser-control tool is callable. Earlier release results below are historical and are not substituted for current live-service acceptance.


Exact public URL: https://astroflare-research-2026.ajuponnu2009.chatgpt.site/
Project appgprj_6af7a9a4f6748191bdc90847b966765a; branch main; existing public audience retained. The original Render deployment and numerical assessment engine are unchanged.

**AI remains inactive pending the API key.** No key was added, no provider activated and no AI answer simulated. The research lookup is deterministic and cited. Existing optional screening AI code is retained.

## Reproduced and fixed

- Published Airflow 20 cm/s → Silicone: “1 of 3” but only Saffire I listed as removed. Feedback now accounts for all current included and excluded investigations, including BASS-II.
- Blank submission left the old answer visible. It now invalidates pending work, clears the answer and asks for a question. Mouse, Enter and all three examples use the same latest-only workflow. Valid rapid switching was already correct and remains covered, including deliberately reversed delayed responses.
- Report-service errors lacked a local retry control. Retry report, Back to results and Open NASA lunar demo are now explicit.
- Some inherited secondary panels used light backgrounds with pale text. Theme-compatible surfaces and chip colors restore contrast. Narrow-width controls and long links are contained.
- Live relay returned 502 while direct Render calls passed. Portable cancellation and explicit manual redirect rejection replace runtime-dependent fetch options; a bounded diagnostic contains no input bodies or credentials.

## Automated release checks

| Area | Status | Conditions / evidence |
| --- | --- | --- |
| Core tests | Pass | 27 Node tests; existing checks retained. |
| Lunar preset | Pass | Fresh unauthenticated DOM; one click yields 3 ranked studies, default two-study comparison and cited takeaway; no remote engine dependency. |
| Filters | Pass | All 5 material, 4 experiment-gravity and 7 airflow choices; 5 combinations; complete included/excluded feedback; separate scenario gravity; reset and preset recovery. |
| Comparison | Pass | Zero, one, two, rejected third selection and filtering out a selected record; checkboxes/count/columns agree. |
| Evidence answers | Pass | Exact Saffire II, Saffire 2, PSI-99; Saffire I gap; lunar gap; explicit silicone question; unrelated and blank inputs; all 3 examples; 12 rapid mixed-method batches per DOM width. |
| Research brief | Pass | Captured clipboard payload for default, silicone and empty evidence; scenario, measured/gap, proposed next step and corresponding sources checked; denied clipboard shows selected manual-copy fallback. |
| Scientific rows | Pass | Eight raw rows parsed and compared against byte-pinned original PSI CSVs; values, units, oxygen, airflow, direction and run IDs retained. |
| Navigation | Pass | DOM Back/Forward and fresh-document restoration of saved research state; hash route; accessible in-page links do not create accidental route changes. |
| Screening contract | Pass | All 4 original example assessments match the original remote engine exactly; guide flow/profile pass. |
| Failure recovery | Pass | Injected screening/report/solar outages retain answers, expose retries and allow the local lunar demo; report Markdown/JSON blobs and print callback tested. |
| Accessibility logic | Pass | Labelled controls, input focus, scroll restoration, keyboard submissions, focusable comparison scrolling, reduced-motion JS/CSS suppression. |
| Declared theme contrast | Pass | Tested normal body, secondary text, source link, button, warning and decision pairs exceed 4.5:1 (lowest tested 6.03:1). This is not a full rendered-page contrast audit. |
| Real-browser visual QA | Blocked | No callable browser-control tool. No rendered desktop or 390 × 844 mobile inspection; native clipboard/print, touch, actual overflow and OS reduced-motion appearance remain unverified. |

DOM widths of 1280 and 390 px test logic with those window settings; JSDOM does not render CSS layout. No browser screenshot, actual viewport measurement or human 30-second timing is claimed.

## Publication acceptance

Run `NODE_USE_ENV_PROXY=1 node test/judge-live.mjs` against the exact URL after deploying. It repeats the judge matrix on the downloaded production bytes, checks anonymous homepage, documentation, verification, source ZIP, dataset, CSVs and health endpoint, opens every PSI record and original table, and compares original/pinned source hashes. It also records NASA NTRS and official challenge availability. No cookies, login, bypass token or API key are supplied.

Run `NODE_USE_ENV_PROXY=1 node test/mission-live.mjs` for the visible manual-entry mission path through the real public relay, fresh assessment, report generation, actual Markdown/JSON payloads and solar appendix. AI is suppressed during this check. A failed remote call must not be described as a successful mission flow; its recovery remains separately tested.

Original NASA files:
- PSI-25_Experimental table_BASS-II.csv: T1, T2, T4 and B1.
- PSI-99_Experimental table_SAFFIRE-2.csv: 2-5 and 2-1.
- PSI-98_Experimental table_SAFFIRE-1.csv: S1 and S2.

Saffire II row 2-5 is SIBAL, 2.1 mm/s, microgravity, 20 cm/s concurrent flow and approximately 22.1% O₂ (derived per Note 1). Silicone row 2-1 reports burn time “Insignificant”, a qualitative observation, not zero and not a spread rate. No selected direct lunar-gravity measurement is presented. Source geometry/header inconsistencies remain disclosed; original files are not silently corrected. Full citations and caveats: /documentation and /dataset.json.

The official challenge page previously returned HTTP 503. Record its actual status in each live run; it is external to the app. NASA evidence remains accessible through original links and pinned source downloads.

## Final manual review still required

In a genuinely signed-out browser, open the exact URL on desktop and at 390 × 844. Check visual comparison readability, no page-wide horizontal overflow, keyboard focus and mobile touch, then enable OS reduced motion. Copy and paste the brief into an editor and open a native report download. This step is blocked in the current tooling, not silently marked passed.

## 30-second judging sequence

0–5 s: Home → Run the lunar habitat demo.
5–12 s: Show What NASA measured, the lunar evidence gap and Next research step.
12–18 s: Material / fuel → Silicone; show 1 included / 2 excluded and the changed qualitative takeaway.
18–23 s: Copy research brief + citations, then View comparison.
23–30 s: Ask about the evidence → Saffire II example → Original NASA table, row 2-5. Its explicit SIBAL conditions distinguish this named catalogue lookup from the silicone-filtered dashboard.

## Journal redesign and audit-fix acceptance

The latest release replaces the earlier dark/orb design with flat ivory, near-black, brick red and restrained source blue. Instrument Serif and Instrument Sans are bundled locally. No external font dependency is required for the main experience. The original experiment plate uses only a specimen and documented relative flow/spread direction, with **Test schematic · not to scale**. Mobile document order places the headline and demo button before the plate.

| Latest audit item | Status | Verification conditions |
| --- | --- | --- |
| Experiment plate | Pass (DOM) | Both native button controls switch material, run, observation and row citation atomically; no SIBAL number in silicone state. Focus retained; reduced-motion preference suppresses switch animation. Fresh DOM widths 1280/390, not rendered viewports. |
| I²t terminology | Pass (frontend) | Rendered demo, incoming assessment/report normalization and exported Markdown/JSON use fault current integral (I²t); exact 112.5 value and A²·s unit retained. Original remote engine and raw API/archive wording are outside this frontend correction. |
| Silicone + opposed flow | Pass (DOM) | Prior live mismatch reproduced; study-only match plus zero jointly matching curated runs shown beside result and comparison, and in copied brief. Displayed row 2-1 remains concurrent. Proposed next step first retrieves matching evidence. |
| BASS-II / Saffire II rationale | Pass (DOM) | Default broad ranking versus supporting rate explained; changes when filters make Saffire II first, leave only BASS-II or return no evidence. |
| Saffire I companion rates | Pass (source + DOM) | PSI omission retained; separately linked NTRS Table I page 29: 1-1, concurrent, 1.8 mm/s; 1-2, opposed, 1.3 mm/s; both 20 cm/s. PSI and NTRS citations remain separate. |
| AI inactive | Pass | False activation gate tested against a service response advertising AI availability; no generated request sent. Existing integration code retained. |
| Desktop and 390 px visual/keyboard/OS review | Blocked | No callable browser-control tool; real rendering, native Tab/Space activation, touch, actual overflow and OS animation appearance cannot be verified here. Programmatic focus, Enter submission and reduced-motion logic pass. |

The legacy measurements CSV also corrects Saffire I sample 1-2 oxygen to approximately 21.5%, per NTRS Table I. The plate uses PSI's approximately 21.5% O₂ for silicone row 2-1; the companion presentation lists approximately 22.1%. This discrepancy is explicitly recorded in /documentation rather than silently normalized.

### Revised recording path

0–6 s: Open homepage; show SIBAL plate, then click Silicone to reveal qualitative versus measured evidence.
6–11 s: Click Run the lunar habitat demo.
11–19 s: Show the ranked-study/supporting-study explanation and the proposed next step.
19–25 s: Select Silicone and Opposed-flow investigation; show study match versus curated-run gap.
25–30 s: Copy research brief + citations, then open the original NASA table from the takeaway.

## Post-publication result — journal release

**Pass:** exact public homepage returned 200 anonymously; complete core and journal DOM suites passed at configured widths 1280/390 with zero uncaught DOM errors. Both plate controls, examples, brief copy payload, Silicone + Opposed case, comparison, Saffire I/II and lunar gap passed on deployed bytes. All NASA PSI records/metadata/tables returned 200; original and pinned CSV hashes matched. NTRS record and PDF returned 200 and the PDF matched the reviewed source hash. Documentation, source archive, dataset, legacy measurement CSV and four bundled font files returned 200. Initial anonymous homepage delivery in this run was 824 ms; DOM timing is not rendered-browser/human timing.

**Blocked:** the subsequent real manual screening path and hypothetical-demo report request both received HTTP 429 from the original remote engine. Fresh live Markdown/JSON export verification therefore did not pass in this release. Local export tests using the preserved engine report fixture passed: corrected terminology, exact 112.5 A²·s, valid Markdown/JSON. Earlier production screening/report runs succeeded before this service limit. The release adds a clear rate-limit message, keeps answers, exposes retry/research recovery and forwards Retry-After when present; no automatic retry is added. The upstream service owner must resolve its rate limit before repeating `test/mission-live.mjs`.

**Blocked:** real desktop and 390 px mobile rendering/native keyboard/touch/clipboard/OS reduced-motion inspection, because no browser-control tool is callable. **External issue:** the official challenge brief returned HTTP 503. Neither limitation is presented as a passing check.
