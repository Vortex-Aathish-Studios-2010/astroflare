  // "For research labs": the business hypothesis, stated plainly. Targets and plans are labelled as such; nothing here
  // is a customer, revenue, partnership or NASA endorsement.
  function openLabs(){cancelEvidence();goTo('labs');}
  function renderLabs(st){
    const wrap=el('section',{class:'labs',id:'labs-page','aria-labelledby':'labs-title'});
    wrap.appendChild(el('p',{class:'eyebrow',text:'For research labs'}));
    wrap.appendChild(el('h1',{id:'labs-title',text:'Turn NASA combustion evidence into your next research question.'}));
    wrap.appendChild(el('p',{class:'lede',text:'Compare experiments, understand their conditions, and build a research brief with sources you can trace.'}));
    wrap.appendChild(el('p',{class:'notice',id:'labs-hypothesis',text:'Our business model is an early hypothesis that we still have to validate. This page has no customers, revenue, partnerships or testimonials to report, and NASA does not endorse AstroFlare.'}));
    const go=el('div',{class:'row labs-actions'});const demo=el('button',{type:'button',class:'btn primary',id:'labs-demo',text:'Run the lunar habitat demo'});demo.addEventListener('click',openLunarDemo);go.appendChild(demo);go.appendChild(el('a',{class:'btn',href:'#pilot',text:'Discuss a research pilot'}));wrap.appendChild(go);
    const crit=[['Customer','University combustion and materials-science researchers are our initial users.'],['Buyer','A laboratory director, principal investigator or university department could pay for the team workspace.'],['Problem','Researchers need to match published experiments to their conditions and document why the evidence supports their proposed investigation.'],['Value','AstroFlare connects a research question to relevant experiments, source conditions, evidence gaps and a reusable research brief.'],['Revenue','Public exploration stays free. We propose paid collaboration, project history and maintained evidence collections.'],['Validation','We will test whether labs return, produce accurate research briefs and are willing to pay. Targets are listed below and none has been achieved.']];
    const c=el('section',{class:'labs-block',id:'labs-criteria','aria-labelledby':'criteria-title'},[el('h2',{id:'criteria-title',text:'The business in six lines'}),el('dl',{class:'criteria'},crit.flatMap(([k,v])=>[el('dt',{text:k}),el('dd',{text:v})]))]);wrap.appendChild(c);
    wrap.appendChild(el('section',{class:'labs-block',id:'labs-journey','aria-labelledby':'journey-title'},[el('h2',{id:'journey-title',text:'One customer journey'}),el('p',{text:'A university lab is preparing a material-flammability investigation. Its researchers compare relevant NASA experiments, identify conditions that differ from their scenario, and create a cited proposal for further research.'}),el('p',{class:'small',text:'The Public Explorer already lets you try this with the lunar habitat demo.'})]));
    const free=el('div',{class:'offer',id:'offer-public'},[el('p',{class:'status-tag available',text:'Free · Available now'}),el('h3',{text:'Public Explorer'}),el('ul',{},['The lunar habitat demonstration','Filters, ranking and side-by-side comparison','NASA citations for every value','A research brief you can copy','Saved research projects with Markdown and JSON export (kept in this browser only)'].map(t=>el('li',{text:t})))]);
    const paid=el('div',{class:'offer',id:'offer-workspace'},[el('p',{class:'status-tag planned',text:'Planned · Not built yet'}),el('h3',{text:'Research Lab Workspace'}),el('ul',{},['Planned: shared projects','Planned: reviewer comments','Planned: version history','Planned: reviewed additions to the evidence collection'].map(t=>el('li',{text:t}))),el('p',{class:'small',text:'None of these exist yet. There is no account system, sign-up or checkout.'})]);
    wrap.appendChild(el('section',{class:'labs-block',id:'labs-offers','aria-labelledby':'offers-title'},[el('h2',{id:'offers-title',text:'Two offerings'}),el('div',{class:'offer-pair'},[free,paid])]));
    wrap.appendChild(el('section',{class:'labs-block',id:'labs-pricing','aria-labelledby':'pricing-title'},[el('h2',{id:'pricing-title',text:'Pricing hypothesis'}),el('p',{class:'pricing',id:'pricing-statement',text:'Proposed pilot pricing: US$49 per lab/month. We will test this price with research teams before launching subscriptions.'}),el('p',{class:'small',text:'This is a pricing hypothesis, not a researched market benchmark or an active subscription. There is no checkout.'})]));
    const tests=['Can researchers identify relevant evidence correctly?','Can they distinguish measurements from missing evidence?','How long does a comparable review take with and without AstroFlare?','Do they return to saved projects?','Would the lab’s budget holder pay for the proposed workspace?'];
    wrap.appendChild(el('section',{class:'labs-block',id:'labs-validation','aria-labelledby':'validation-title'},[el('h2',{id:'validation-title',text:'What we will test with pilot labs'}),el('ul',{},tests.map(t=>el('li',{text:t}))),el('p',{class:'target',text:'Initial recruitment target (a future target, not a result): three labs and ten observed research-review tasks.'}),el('p',{class:'small',text:'Any price has to cover hosting, support and the human time needed to review the evidence collection. We are not publishing savings, profit or market-size figures because we have none.'})]));
    wrap.appendChild(renderPilot());
    st.appendChild(wrap);
  }
  // A pilot enquiry is only possible through a published, verified address. Opening an email draft does not send anything,
  // so the page says so and never claims an enquiry was received.
  function renderPilot(){
    const box=el('section',{class:'labs-block pilot',id:'pilot',tabindex:'-1','aria-labelledby':'pilot-title'},[el('h2',{id:'pilot-title',text:'Discuss a research pilot'})]);
    const addr=typeof CONTACT_EMAIL==='string'&&/^[^\s@<>"']+@[^\s@<>"']+\.[A-Za-z]{2,}$/.test(CONTACT_EMAIL)?CONTACT_EMAIL:'';
    if(addr){
      box.appendChild(el('p',{text:'If your lab would like to try AstroFlare for a material-flammability review, tell us about your research need. Include your name, institution and what you are investigating.'}));
      box.appendChild(el('p',{},[el('a',{class:'btn primary',id:'pilot-email',href:'mailto:'+addr+'?subject='+encodeURIComponent('AstroFlare research pilot enquiry'),text:'Email the team'}),' ',el('span',{class:'small',text:addr})]));
      box.appendChild(el('p',{class:'small',id:'pilot-note',text:'This opens your email app with a draft. We only receive your enquiry when you send that email. This page does not send or store anything.'}));
    }else{
      box.appendChild(el('p',{class:'notice warn',id:'pilot-unavailable',role:'note',text:'We have not published a contact address on this site yet, and there is no enquiry form. Pilot enquiries cannot be sent from this page at the moment.'}));
    }
    return box;
  }
